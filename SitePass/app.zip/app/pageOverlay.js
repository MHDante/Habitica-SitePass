function btn1(){
    if(!btn){
        var btn = document.createElement("BUTTON");
        btn.classList.add('blockedSite_btn'); 
        btn.innerHTML = "CLICK ME";                   
        document.body.appendChild(btn); 
        btn.onclick = aaaa;
    }
}
function test(a){
    alert(a);
}